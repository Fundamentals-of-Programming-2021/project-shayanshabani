#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>
#include<SDL2/SDL2_gfxPrimitives.h>
#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>
#include<math.h>

#define SCREEN_WIDTH  1280
#define SCREEN_HEIGHT  600
#define WIDTH 4
#define HEIGHT 4
#define speed 5
const int FPS = 60;
double tangent;
int NUM = 6;
SDL_Window *window = NULL;
SDL_Surface *surface = NULL;
SDL_Texture *volume_texture = NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *hexes[6];
SDL_Texture *potions[4];
TTF_Font *font_volume;
int r_map[WIDTH][HEIGHT];
char* s_map[20];
int saved = 0;
char* p_hex[] = {"pictures/green.png", "pictures/orange.png", "pictures/grey.png", "pictures/purple.png", "pictures/blue.png", "pictures/yellow.png"};
int flag = 0;
char *potion_address[] = {"PotionRed.png", "PotionYellow.png", "PotionBlue.png", "PotionPurple.png"};
int active_potion[4] = {0};
struct region {
    int x;
    int y;
    int soldiers;
    int color;
    double speed_y;
    double speed_x;
    int flow_x;
    int flow_y;
    int is_active_potion;
    struct soldier {
        double x;
        double y;
        int color;
    }all_soldiers[500];
} regions[16];
int coins = 0;
int number_of_regions[6] = {0};

bool init();
void user();
int menu();
void maping1();
void maping2();
void load_saved_map();
void hexex();
void hexex2();
void hexagon(int, int, int, int, int, int);
void game();
int check_position(int, int, int);
void origin_and_destination(int k, int z, int dx, int dy);

int main() {
    if (!init()) {
        return 1;
    }
    srand(time(NULL));
    user();
    if (flag) {
        ///printf("it was successful!\n");
        int plan = menu();
        ///printf("%d\n", plan);
        switch(plan) {
            case -1:
                printf("Good lock\n");
                break;
            case 0:
                //Map
                load_saved_map();
                break;
            case 1:
                //new-game
                maping2();
                break;
            case 2:
                //chart
                break;
            case 3:
                //exit
                break;
        }
    }
    printf("missoin completed!\n");
    printf("%d\n", coins);
    SDL_DestroyTexture(volume_texture);
    volume_texture = NULL;
    SDL_FreeSurface(surface);
    surface = NULL;
    SDL_DestroyRenderer(renderer);
    renderer = NULL;
    SDL_DestroyWindow(window);
    window = NULL;
    SDL_Quit();
    TTF_Quit();
    IMG_Quit();
}

bool init() {

    if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {
        printf("failed to init! error: %s\n", SDL_GetError());
        return false;
    }
    if (IMG_Init(IMG_INIT_PNG) < 0) {
        printf("failed to init IMG! error: %s\n", IMG_GetError());
        return false;
    }
    if (TTF_Init() < 0) {
        printf("failed to init TTF! error: %s\n", TTF_GetError());
        return false;
    }
    window = SDL_CreateWindow("State.io", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    if (window == NULL) {
        printf("failed to create window! error: %s\n", SDL_GetError());
        return false;
    }
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);
    if (renderer == NULL) {
        printf("failed to create renderer from window! error: %s\n", SDL_GetError());
        return false;
    }
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    return true;
}

void user() {
    SDL_Event event;
    SDL_StartTextInput();
    TTF_Font *font1 = TTF_OpenFont("LiberationSerif-Regular.ttf", 24);
    TTF_Font *font2 = TTF_OpenFont("LiberationSerif-Regular.ttf", 56);
    ///image : welcome to the desert of the real
    SDL_Surface *image = IMG_Load("desert_of_the_real_copy.png");
    SDL_Texture *texture1 = SDL_CreateTextureFromSurface(renderer, image);
    SDL_Rect rect1;
    rect1.x = 0;
    rect1.y = 0;
    rect1.w = SCREEN_WIDTH;
    rect1.h = SCREEN_HEIGHT / 2;
    ///message : Enter your user-name
    char message[25] = "Enter your user-name:";
    SDL_Rect rect2;
    SDL_Texture *texture2;
    SDL_Color message_color = {6, 82, 9};
    SDL_Surface *message_surface = TTF_RenderText_Solid(font2, message, message_color);
    texture2 = SDL_CreateTextureFromSurface(renderer, message_surface);
    rect2.x = (SCREEN_WIDTH / 2) - (message_surface->w / 2);
    rect2.y = rect1.h + 20;
    rect2.w = message_surface->w;
    rect2.h = message_surface->h;
    ///TextInput handling
    SDL_Surface *text_surface = NULL;
    SDL_Texture *texture3 = NULL;
    char input[100] = "\0";
    bool doing = true;
    while(doing) {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        while (SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    doing = false;
                    break;
                case SDL_TEXTINPUT:
                    strcat(input, event.text.text);
                    break;
                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_BACKSPACE && strlen(input)) {
                        input[strlen(input) - 1] = '\0';
                    }
                    else if (event.key.keysym.sym == SDLK_RETURN && strlen(input)) {
                        doing = false;
                        flag = 1;
                    }
                    break;
            }
        }
        ///show the input string
        if (strlen(input)) {
            text_surface = TTF_RenderText_Solid(font1, input, message_color);
            texture3 = SDL_CreateTextureFromSurface(renderer, text_surface);
            SDL_Rect rect3;
            rect3.x = (SCREEN_WIDTH / 2) - (text_surface->w / 2);
            rect3.y = rect1.h + rect2.h + 30;
            rect3.w = text_surface->w;
            rect3.h = text_surface->h;
            SDL_RenderCopy(renderer, texture3, NULL, &rect3);
        }
        ///show image and message
        SDL_RenderCopy(renderer, texture1, NULL, &rect1);
        SDL_RenderCopy(renderer, texture2, NULL, &rect2);
        SDL_RenderPresent(renderer);
        SDL_Delay(50);
    }
    ///free memory if X pressed
    SDL_FreeSurface(message_surface);
    message_surface = NULL;
    SDL_FreeSurface(image);
    image = NULL;
    SDL_FreeSurface(text_surface);
    text_surface = NULL;
    SDL_DestroyTexture(texture3);
    texture3 = NULL;
    SDL_DestroyTexture(texture1);
    texture1 = NULL;
    SDL_DestroyTexture(texture2);
    texture2 = NULL;
    TTF_CloseFont(font1);
    TTF_CloseFont(font2);
}
int menu() {
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    ///menu making
    SDL_Event event;
    TTF_Font *font = TTF_OpenFont("LiberationSerif-Regular.ttf", 40);
    SDL_Surface *menu[4];
    SDL_Rect rect[4];
    bool selected[4] = {0, 0, 0, 0};
    char choices[4][15] = {"Map", "NewGame", "Chart", "Exit"};
    SDL_Color color[2] = {{0, 255, 0}, {255, 0, 0}};
    menu[0] = TTF_RenderText_Solid(font, choices[0], color[0]);
    menu[1] = TTF_RenderText_Solid(font, choices[1], color[0]);
    menu[2] = TTF_RenderText_Solid(font, choices[2], color[0]);
    menu[3] = TTF_RenderText_Solid(font, choices[3], color[0]);
    SDL_Texture *t_menu[4];
    t_menu[0] = SDL_CreateTextureFromSurface(renderer, menu[0]);
    t_menu[1] = SDL_CreateTextureFromSurface(renderer, menu[1]);
    t_menu[2] = SDL_CreateTextureFromSurface(renderer, menu[2]);
    t_menu[3] = SDL_CreateTextureFromSurface(renderer, menu[3]);
    ///decide on position
    for (int i = 0, j = 25; i < 4; i++, j += 100) {
        rect[i].x = (SCREEN_WIDTH / 2) - (menu[i]->w / 2);
        rect[i].y = j;
        rect[i].w = menu[i]->w;
        rect[i].h = menu[i]->h;
    }
    bool doing = true;
    int x, y, result = -1;
    while (doing) {
        while (SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    doing = false;
                case SDL_MOUSEMOTION:
                    x = event.motion.x;
                    y = event.motion.y;
                    for (int i = 0; i < 4; i++) {
                        if (x >= rect[i].x && x <= (rect[i].x + rect[i].w) && y >= rect[i].y && y <= (rect[i].y + rect[i].h)) {
                            if (!selected[i]) {
                                selected[i] = 1;
                                SDL_FreeSurface(menu[i]);
                                SDL_DestroyTexture(t_menu[i]);
                                menu[i] = TTF_RenderText_Solid(font, choices[i], color[1]);
                                t_menu[i] = SDL_CreateTextureFromSurface(renderer, menu[i]);
                            }
                        }
                        else {
                            if (selected[i]) {
                                selected[i] = 0;
                                SDL_FreeSurface(menu[i]);
                                SDL_DestroyTexture(t_menu[i]);
                                menu[i] = TTF_RenderText_Solid(font, choices[i], color[0]);
                                t_menu[i] = SDL_CreateTextureFromSurface(renderer, menu[i]);
                            }
                        }
                    }
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    x = event.button.x;
                    y = event.button.y;
                    for (int i = 0; i < 4; i++) {
                        if (x >= rect[i].x && x <= (rect[i].x + rect[i].w) && y >= rect[i].y && y <= (rect[i].y + rect[i].h)) {
                            result = i;
                        }
                    }
                    doing = false;
            }
        }
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        for (int i = 0; i < 4; i++) {
            SDL_RenderCopy(renderer, t_menu[i], NULL, &rect[i]);
        }
        SDL_RenderPresent(renderer);
        SDL_Delay(50);
    }
    for (int i = 0; i < 4; i++) {
        SDL_FreeSurface(menu[i]);
        menu[i] = NULL;
        SDL_DestroyTexture(t_menu[i]);
        t_menu[i] = NULL;
    }
    TTF_CloseFont(font);
    return result;
}

void maping1() {
    int my_flag = 0;
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            r_map[j][i] = rand() % NUM;
        }

    }
    for (int i = 0; i < NUM; i++) {
        for (int j = 0; j < HEIGHT; j++){
            for (int k = 0; k < WIDTH; k++) {
                if (r_map[k][j] == i) {
                    my_flag++;
                }
            }
        }
        if (!my_flag) {
            break;
        }
        else if (i < NUM - 1){
            my_flag = 0;
        }
    }
    if (!my_flag) {
        maping1();
    }
}

void load_saved_map() {
    TTF_Font *map_font = TTF_OpenFont("LiberationSerif-Regular.ttf", 50);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    SDL_Color map_color = {0, 255, 0};
    surface = TTF_RenderText_Solid(map_font, "Choose from 1 to 5", map_color);
    volume_texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect map;
    map.x = (SCREEN_WIDTH / 2) - (surface->w);
    map.y = 90;
    map.w = surface->w;
    map.h = surface->h;
    bool running = true;
    SDL_Event first_event;
    while (running) {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        while (SDL_PollEvent(&first_event)) {
            switch(first_event.type) {
                case SDL_QUIT:
                    TTF_CloseFont(map_font);
                    SDL_FreeSurface(surface);
                    surface = NULL;
                    SDL_DestroyTexture(volume_texture);
                    volume_texture = NULL;
                    return;
                case SDL_KEYDOWN:
                    switch(first_event.key.keysym.sym) {
                        case SDLK_1:
                            NUM = 2;
                            for (int i = 0; i < WIDTH; i++) {
                                for (int j = 0; j < HEIGHT; j++) {
                                    if (i == 2 && j == 2) {
                                        r_map[i][j] = 1;
                                    }
                                    else {
                                        r_map[i][j] = 0;
                                    }
                                }
                            }
                            running = false;
                            break;
                        case SDLK_2:
                            running = false;
                            break;
                        case SDLK_3:
                            running = false;
                            break;
                        case SDLK_4:
                            running = false;
                            break;
                        case SDLK_5:
                            running = false;
                            break;
                    }
            }
        }
        SDL_RenderCopy(renderer, volume_texture, NULL, &map);
        SDL_RenderPresent(renderer);
        SDL_Delay(50);
    }
    TTF_CloseFont(map_font);
    SDL_FreeSurface(surface);
    surface = NULL;
    SDL_DestroyTexture(volume_texture);
    volume_texture = NULL;
    for (int i = 0; i < NUM; i++) {
        hexes[i] = IMG_LoadTexture(renderer, p_hex[i]);
    }
    SDL_Event event;
    bool doing = true;
    while (doing) {
        hexex();
        SDL_RenderClear(renderer);
        while (SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    ///destroy everything
                    doing = false;
                    break;
                case SDL_KEYDOWN:
                    /// if a key pressed
                    if (event.key.keysym.sym == SDLK_RETURN) {
                        ///if the map being chosen
                        game();
                        doing = false;
                        break;
                    }
                    else if (event.key.keysym.sym == SDLK_ESCAPE) {
                        ///if key "esc" pressed -> get out of the current position
                        doing = false;
                        flag = 1;
                        break;
                    }
                default:
                    break;
            }
        }
    }
    for (int i = 0; i < 2; i++) {
        SDL_DestroyTexture(hexes[i]);
        hexes[i] = NULL;
    }
    if (flag) {
        int flag2 = menu();
        switch(flag2) {
            case -1:
                ///closing the window
                break;
            case 0:
                ///Map
                load_saved_map();
                break;
            case 1:
                ///new Game
                maping2();
                break;
            case 2:
                ///Chart
                break;
            case 3:
                ///Exit
                break;
        }
    }
}

void maping2() {
    font_volume = TTF_OpenFont("LiberationSerif-Regular.ttf", 15);
    flag = 0;
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    TTF_Font *font = TTF_OpenFont("LiberationSerif-Regular.ttf", 60);
    SDL_Color color = {0, 255, 0};
    SDL_Surface *How_many_player = TTF_RenderText_Solid(font, "How many player do you want? choose from 2 to 5", color);
    SDL_Texture *soal = SDL_CreateTextureFromSurface(renderer, How_many_player);
    SDL_Rect soal_position;
    soal_position.x = (SCREEN_WIDTH / 2) - (How_many_player->w / 2);
    soal_position.y = 90;
    soal_position.w = How_many_player->w;
    soal_position.h = How_many_player->h;
    bool running = true;
    SDL_Event first_event;
    while (running) {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        while (SDL_PollEvent(&first_event)) {
            switch(first_event.type) {
                case SDL_QUIT:
                    TTF_CloseFont(font);
                    SDL_FreeSurface(How_many_player);
                    How_many_player = NULL;
                    SDL_DestroyTexture(soal);
                    soal = NULL;
                    return;
                case SDL_KEYDOWN:
                    switch(first_event.key.keysym.sym) {
                        case SDLK_2:
                            NUM = 2;
                            running = false;
                            break;
                        case SDLK_3:
                            NUM = 4;
                            running = false;
                            break;
                        case SDLK_4:
                            NUM = 5;
                            running = false;
                            break;
                        case SDLK_5:
                            NUM = 6;
                            running = false;
                            break;
                        default:
                            break;
                    }
            }
        }
        SDL_RenderCopy(renderer, soal, NULL, &soal_position);
        SDL_RenderPresent(renderer);
        SDL_Delay(50);
    }

    TTF_CloseFont(font);
    SDL_FreeSurface(How_many_player);
    How_many_player = NULL;
    SDL_DestroyTexture(soal);
    soal = NULL;

    for (int i = 0; i < NUM; i++) {
        hexes[i] = IMG_LoadTexture(renderer, p_hex[i]);
    }

    SDL_Event event;
    bool doing = true;
    maping1();
    while (doing) {
        hexex();
        SDL_RenderClear(renderer);
        while (SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    ///destroy everything
                    doing = false;
                    break;
                case SDL_KEYDOWN:
                    /// if a key pressed
                    if (event.key.keysym.sym == SDLK_RETURN) {
                        ///if the map being chosen
                        game();
                        doing = false;
                        break;
                    }
                    else if (event.key.keysym.sym == SDLK_x) {
                        ///if key "x" pressed -> generate a new map
                        maping1();
                        break;
                    }
                    else if (event.key.keysym.sym == SDLK_ESCAPE) {
                        ///if key "esc" pressed -> get out of the current position
                        doing = false;
                        flag = 1;
                        break;
                    }
                default:
                    break;
            }
        }
    }
    for (int i = 0; i < NUM; i++) {
        SDL_DestroyTexture(hexes[i]);
    }
    if (flag) {
        int flag2 = menu();
        switch(flag2) {
            case -1:
                ///closing the window
                break;
            case 0:
                ///continue
                break;
            case 1:
                ///new Game
                maping2();
                break;
            case 2:
                ///Chart
                break;
            case 3:
                ///Exit
                break;
        }
    }
    TTF_CloseFont(font_volume);
}

void hexex() {
    ///decide on the position of hexagons
    int x_pos, y_pos, odd, aim_hexagon;
    int k = 0;
    odd = 1;
    for (int i = 0; i < HEIGHT; i++) {
        y_pos = i * 140;
        for (int j = 0; j < WIDTH; j++) {
            x_pos = j * 250;
            if ((j >= 0 && j < WIDTH) && (i >= 0 && i < HEIGHT)) {
                aim_hexagon = r_map[j][i];
                hexagon(aim_hexagon, x_pos, y_pos, odd, k, 0);
                k++;
            }
        }
        odd = 1 - odd;
    }
    SDL_RenderPresent(renderer);
    SDL_Delay(50);
}


void hexagon(int a, int b, int c, int d, int k, int z) {
    ///rendering hexagons to the renderer
    SDL_Rect source, destination;
    int e = 170;
    ///set the destination in map for every hexagon
    destination.h = 180;
    destination.w = 170;
    destination.x = (Sint16)(b + (d * e / 2));
    destination.y = (Sint16)c;
    source.h = 180;
    source.w = 170;
    source.x = 0;
    source.y = 0;
    regions[k].x = destination.x + 72;
    regions[k].y = destination.y + 120;
    char region_volume[5];
    int length = 0;
    if (z) {
        int p = regions[k].soldiers;
        if (p) {
            while (p) {
                length++;
                p /= 10;
            }
            p = regions[k].soldiers;
            for (int i = length - 1; i >= 0; i--) {
                region_volume[i] = p % 10 + 48;
                p /= 10;
            }
            p = regions[k].soldiers;
            if (p >= 40) {
                region_volume[length] = 'm';
                region_volume[length + 1] = 'a';
                region_volume[length + 2] = 'x';
                region_volume[length + 3] = '\0';
            }
            else {
                region_volume[length] = '\0';
            }
        }
        else {
            region_volume[0] = '0';
            region_volume[1] = '\0';
        }
    }
    else {
        regions[k].is_active_potion = 0;
        regions[k].color = a;
        number_of_regions[a]++;
        if (a) {
            regions[k].soldiers = 25;
            region_volume[0] = '2';
            region_volume[1] = '5';
            region_volume[2] = '\0';
            for (int i = 0; i < 100; i++) {
                regions[k].all_soldiers[i].x = regions[k].x;
                regions[k].all_soldiers[i].y = regions[k].y;
                regions[k].all_soldiers[i].color = regions[k].color;
            }
        }
        else {
            regions[k].soldiers = 30;
            region_volume[0] = '3';
            region_volume[1] = '0';
            region_volume[2] = '\0';
            for (int i = 0; i < 100; i++) {
                regions[k].all_soldiers[i].x = regions[k].x;
                regions[k].all_soldiers[i].y = regions[k].y;
                regions[k].all_soldiers[i].color = regions[k].color;

            }
        }
    }
    SDL_Color color = {255, 255, 255, 255};
    //TTF_Font *font = TTF_OpenFont("LiberationSerif-Regular.ttf", 15);
    surface = TTF_RenderText_Solid(font_volume, region_volume, color);
    volume_texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect rect;
    ///the position of the volume of the region
    rect.x = regions[k].x;
    rect.y = regions[k].y;
    rect.w = surface->w;
    rect.h = surface->h;
    SDL_RenderCopy(renderer, hexes[regions[k].color], &source, &destination);
    SDL_RenderCopy(renderer, volume_texture, NULL, &rect);
    //TTF_CloseFont(font);
    SDL_DestroyTexture(volume_texture);
    volume_texture = NULL;
    SDL_FreeSurface(surface);
    surface = NULL;
}

void game() {
    Uint32 coloring[6];
    ///set colors for soldiers
    coloring[0] = 0xff003300;
    coloring[1] = 0xff0f0ff6;
    coloring[2] = 0xff000000;
    coloring[3] = 0xff330033;
    coloring[4] = 0xff660000;
    coloring[5] = 0xff00ffff;
    SDL_Event event;
    bool run = true;
    int x, y;
    int dx, dy;
    int k[16];
    int z[16];
    int t[16];
    int o[16];
    int much = 0;
    int w[16] = {0};
    int q[16] = {0};
    int max_soldiers[16];
    int u[16][500] = {0};
    for (int i = 0; i < 16; i++) {
        k[i] = -1;
        z[i] = -1;
        w[i] = 1;
    }
    int another_flag = 0;
    int x_flag = 1;
    int bb = 0;
    int won = 0;
    int xxx = 0;
    for (int i = 0; i < 4; i++) {
        potions[i] = IMG_LoadTexture(renderer, potion_address[i]);
    }
    while (run) {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        xxx = 0;
        for (int i = 0; i < 16; i++) {
            if (regions[i].color == 0) {
                xxx++;
            }
        }
        if (xxx == 16 || xxx == 0) {
            run = false;
        }
        while (SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    run = false;
                    return;
                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_ESCAPE) {
                        run = false;
                        flag = 1;
                        return;
                    }
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    switch (another_flag) {
                        case 0:
                            ///if an origin selected
                            x = event.button.x;
                            y = event.button.y;
                            ///loop over possible regions
                            for (int i = 0; i < 16; i++) {
                                t[much] = check_position(x, y, i);
                                if (!t[much]) {
                                    k[much] = i;
                                    for (int pp = 0; pp < much; pp++) {
                                        if (k[pp] == i) {
                                            k[pp] = -1;
                                        }
                                    }
                                    i = 17;
                                    another_flag = 1;
                                }
                            }
                            break;
                        case 1:
                            ///if a destination selected
                            x = event.button.x;
                            y = event.button.y;
                            ///loop over possible regions
                            for (int i = 0; i < 16; i++) {
                                o[much] = check_position(x, y, i);
                                if (o[much] != -1) {
                                    z[much] = i;
                                    i = 17;
                                    ///find the velocity of the soldiers
                                    origin_and_destination(k[much], z[much], dx, dy);
                                    max_soldiers[much] = regions[k[much]].soldiers;
                                    regions[k[much]].soldiers--;
                                    much++;
                                    another_flag = 0;
                                }
                            }
                            break;
                    }
                    break;
            }
        }
        ///create the map
        hexex2();
        if (won % 300 == 0) {
            for (int i = 0; i < 16; i++) {

                if (regions[i].color == 0 || regions[i].color == 2) {
                    continue;
                }

                if (regions[i].soldiers >= 35) {
                    x_flag = 1;
                    for (int pp = 0; pp < much; pp++) {
                        if (k[pp] == i) {
                            pp = much + 1;
                            x_flag = 0;
                        }
                    }
                    if (x_flag) {
                        t[much] = regions[i].color;
                        k[much] = i;
                        for (int j = 0; j < 16; j++) {

                            if (regions[j].color != regions[i].color) {

                                if (number_of_regions[2] && regions[j].color == 2) {
                                    o[much] = regions[j].color;
                                    z[much] = j;
                                    origin_and_destination(k[much], z[much], dx, dy);
                                    max_soldiers[much] = regions[k[much]].soldiers;
                                    regions[k[much]].soldiers--;
                                    much++;
                                    j = 17;
                                    i = 17;
                                    won++;
                                } else if (regions[j].soldiers <= 10) {
                                    o[much] = regions[j].color;
                                    z[much] = j;
                                    origin_and_destination(k[much], z[much], dx, dy);
                                    max_soldiers[much] = regions[k[much]].soldiers;
                                    regions[k[much]].soldiers--;
                                    much++;
                                    j = 17;
                                    i = 17;
                                    won++;
                                } else if (number_of_regions[regions[j].color] < 3) {
                                    o[much] = regions[j].color;
                                    z[much] = j;
                                    origin_and_destination(k[much], z[much], dx, dy);
                                    max_soldiers[much] = regions[k[much]].soldiers;
                                    regions[k[much]].soldiers--;
                                    much++;
                                    j = 17;
                                    i = 17;
                                    won++;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (won % 300 != 0) {
            won++;
        }
        ///loop over every region
        for (int i = 0; i < much; i++) {
            if (z[i] != -1 && k[i] != -1) {
                ///loop over soldiers in every region
                for (int j = 0; j < w[i]; j++) {
                    for (int qq = 0; qq < much; qq++) {
                        if (regions[k[qq]].color == regions[k[i]].color || regions[k[qq]].color == 2) {
                            continue;
                        }
                        for (int ii = 0; ii < w[qq]; ii++) {
                            if (((regions[k[i]].all_soldiers[j].x - regions[k[qq]].all_soldiers[ii].x < 3 &&
                                  regions[k[i]].all_soldiers[j].x >= regions[k[qq]].all_soldiers[ii].x) ||
                                 (regions[k[qq]].all_soldiers[ii].x - regions[k[i]].all_soldiers[j].x < 3 &&
                                  regions[k[i]].all_soldiers[j].x <= regions[k[qq]].all_soldiers[ii].x)) &&
                                ((regions[k[i]].all_soldiers[j].y - regions[k[qq]].all_soldiers[ii].y < 3 &&
                                  regions[k[i]].all_soldiers[j].y >= regions[k[qq]].all_soldiers[ii].y) ||
                                 (regions[k[qq]].all_soldiers[ii].y - regions[k[i]].all_soldiers[j].y < 3 &&
                                  regions[k[i]].all_soldiers[j].y <= regions[k[qq]].all_soldiers[ii].y)) &&
                                  ((regions[k[i]].all_soldiers[j].x - regions[k[i]].x > 3 ||
                                  regions[k[i]].x - regions[k[i]].all_soldiers[j].x > 3) &&
                                  (regions[k[i]].all_soldiers[j].y - regions[k[i]].y > 3 ||
                                  regions[k[i]].y - regions[k[i]].all_soldiers[j].y > 3) &&
                                  (regions[k[qq]].all_soldiers[ii].x - regions[k[qq]].x > 3 ||
                                  regions[k[qq]].x - regions[k[qq]].all_soldiers[ii].x > 3) &&
                                  (regions[k[qq]].all_soldiers[ii].y - regions[k[qq]].y > 3 ||
                                  regions[k[qq]].y - regions[k[qq]].all_soldiers[ii].y > 3))) {
                                u[i][j] = -1;
                                u[qq][ii] = -1;
                                regions[k[i]].all_soldiers[j].x = regions[k[i]].x;
                                regions[k[i]].all_soldiers[j].y = regions[k[i]].y;
                                regions[k[qq]].all_soldiers[ii].x = regions[k[qq]].x;
                                regions[k[qq]].all_soldiers[ii].y = regions[k[qq]].y;
                            }
                        }
                    }
                    if (u[i][j] != -1) {
                        ///creating every soldier
                        filledCircleColor(renderer, regions[k[i]].all_soldiers[j].x, regions[k[i]].all_soldiers[j].y, 5,coloring[regions[k[i]].all_soldiers[j].color]);

                        if (regions[k[i]].flow_x < 0) {
                            regions[k[i]].all_soldiers[j].x -= regions[k[i]].speed_x;
                        }
                        else {
                            regions[k[i]].all_soldiers[j].x += regions[k[i]].speed_x;
                        }
                        if (regions[k[i]].flow_y < 0) {
                            regions[k[i]].all_soldiers[j].y -= regions[k[i]].speed_y;
                        }
                        else {
                            regions[k[i]].all_soldiers[j].y += regions[k[i]].speed_y;
                        }
                        if (((regions[k[i]].all_soldiers[j].x - regions[z[i]].x < 2 && regions[k[i]].all_soldiers[j].x >= regions[z[i]].x) || (regions[z[i]].x - regions[k[i]].all_soldiers[j].x < 2 && regions[k[i]].all_soldiers[j].x <= regions[z[i]].x)) && ((regions[k[i]].all_soldiers[j].y - regions[z[i]].y < 2 && regions[k[i]].all_soldiers[j].y >= regions[z[i]].y) || (regions[z[i]].y - regions[k[i]].all_soldiers[j].y < 2 && regions[k[i]].all_soldiers[j].y <= regions[z[i]].y))) {
                            u[i][j] = -1;
                            regions[k[i]].all_soldiers[j].x = regions[k[i]].x;
                            regions[k[i]].all_soldiers[j].y = regions[k[i]].y;
                            if (o[i] != t[i]) {
                                regions[z[i]].soldiers--;
                                if (regions[z[i]].soldiers <= 0) {
                                    number_of_regions[regions[z[i]].color]--;
                                    number_of_regions[regions[k[i]].color]++;
                                    regions[z[i]].color = regions[k[i]].color;
                                    regions[z[i]].all_soldiers[0].color = regions[k[i]].color;
                                    o[i] = t[i];
                                    regions[z[i]].soldiers *= -1;
                                }
                            }
                            else {
                                regions[z[i]].soldiers++;
                                regions[z[i]].all_soldiers[regions[z[i]].soldiers - 1].x = regions[z[i]].x;
                                regions[z[i]].all_soldiers[regions[z[i]].soldiers - 1].y = regions[z[i]].y;
                                regions[z[i]].all_soldiers[regions[z[i]].soldiers - 1].color = regions[k[i]].color;
                            }
                            if (j >= max_soldiers[i] - 1) {
                                ///stop sending soldiers
                                z[i] = -1;
                                k[i] = -1;
                                w[i] = 1;
                                ///prepare them for the next journey
                                for (int oo = 0; oo < max_soldiers[i]; oo++) {
                                    u[i][oo] = 0;
                                }
                                j = 100;
                            }
                        }
                    }
                }
                q[i]++;
                ///move every soldier with specific time rate
                if((q[i] % 15 == 0) && (k[i] != -1) && (z[i] != -1) && (regions[k[i]].soldiers > 0)) {
                    w[i]++;
                    regions[k[i]].soldiers--;
                }
            }
        }
        bb++;
        ///increase the number of the soldiers in all of the regions except grey regions that aren't in the game
        if (bb % 60 == 0) {
            for (int i = 0; i < 16; i++) {
                if (regions[i].soldiers < 40 && regions[i].color != 2) {
                    regions[i].soldiers++;
                    regions[i].all_soldiers[regions[i].soldiers - 1].x = regions[i].x;
                    regions[i].all_soldiers[regions[i].soldiers - 1].y = regions[i].y;
                    regions[i].all_soldiers[regions[i].soldiers - 1].color = regions[i].color;
                }
            }
        }

        SDL_RenderPresent(renderer);
        SDL_Delay(1000 / FPS);
    }
    for (int i = 0; i < 4; i++) {
        SDL_DestroyTexture(potions[i]);
        potions[i] = NULL;
    }
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    TTF_Font *font = TTF_OpenFont("LiberationSerif-Regular.ttf", 60);
    SDL_Color color_status = {0, 255, 0, 255};
    bool last_time = true;
    if (xxx) {
        ///won
        surface = TTF_RenderText_Solid(font , "YOU WON +100 coins! Press ESC", color_status);
        coins += 100;
        volume_texture = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_Rect rect_status;
        rect_status.x = (SCREEN_WIDTH / 2) - (surface->w / 2);
        rect_status.y = (SCREEN_HEIGHT / 2) - (surface->h / 2);
        rect_status.w = surface->w;
        rect_status.h = surface->h;
        SDL_Event event_status;
        while (last_time) {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderClear(renderer);
            while(SDL_PollEvent(&event_status)) {
                switch(event.type) {
                    case SDL_QUIT:
                        flag = 0;
                        last_time = false;
                        return;
                    case SDL_KEYDOWN:
                        if (event.key.keysym.sym == SDLK_RETURN || event.key.keysym.sym == SDLK_ESCAPE) {
                            flag = 1;
                            last_time = false;
                            return;
                        }
                        break;
                }
            }
            SDL_RenderCopy(renderer, volume_texture, NULL, &rect_status);
            SDL_RenderPresent(renderer);
            SDL_Delay(50);
        }
    }
    else if (!xxx){
        ///lost
        surface = TTF_RenderText_Solid(font , "YOU LOST -20 coins! Press ESC", color_status);
        coins -= 20;
        volume_texture = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_Rect rect_status;
        rect_status.x = (SCREEN_WIDTH / 2) - (surface->w / 2);
        rect_status.y = (SCREEN_HEIGHT / 2) - (surface->h / 2);
        rect_status.w = surface->w;
        rect_status.h = surface->h;
        SDL_Event event_status;
        while (last_time) {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderClear(renderer);
            while(SDL_PollEvent(&event_status)) {
                switch(event.type) {
                    case SDL_QUIT:
                        flag = 0;
                        last_time = false;
                        return;
                    case SDL_KEYDOWN:
                        if (event.key.keysym.sym == SDLK_RETURN || event.key.keysym.sym == SDLK_ESCAPE) {
                            flag = 1;
                            last_time = false;
                            return;
                        }
                        break;
                }
            }
            SDL_RenderCopy(renderer, volume_texture, NULL, &rect_status);
            SDL_RenderPresent(renderer);
            SDL_Delay(50);
        }
    }
}

int check_position(int x, int y, int i) {
    ///find the region and also check if there is any region at the place which button pressed
    if (((x - regions[i].x < 20 && x >= regions[i].x) || (regions[i].x - x < 20 && regions[i].x >= x)) && ((y - regions[i].y < 20 && y >= regions[i].y) || (regions[i].y - y < 20 && regions[i].y >= y))) {
        return regions[i].color;
    }
    else {
        ///if the button wasn't pressed at proper place
        return -1;
    }
}

void hexex2() {
    ///decide on the position of hexagons
    int x_pos, y_pos, odd, aim_hexagon;
    int k = 0;
    odd = 1;
    for (int i = 0; i < HEIGHT; i++) {
        y_pos = i * 140;
        for (int j = 0; j < WIDTH; j++) {
            x_pos = j * 250;
            if ((j >= 0 && j < WIDTH) && (i >= 0 && i < HEIGHT)) {
                aim_hexagon = r_map[j][i];
                ///z variable is 1 because i don't want to set the number of soldiers in the region to the primary number
                hexagon(aim_hexagon, x_pos, y_pos, odd, k, 1);
                k++;
            }
        }
        odd = 1 - odd;
    }
}

void origin_and_destination(int k, int z, int dx, int dy) {
    dx = regions[z].x - regions[k].x;
    dy = regions[z].y - regions[k].y;
    double des = sqrt((dx * dx) + (dy * dy));
    double portion_x = dx / des;
    if (portion_x < 0) {
        portion_x *= -1;
    }
    double portion_y = dy / des;
    if (portion_y < 0) {
        portion_y *= -1;
    }
    if (dx < 0) {
        regions[k].flow_x = -1;
    }
    else {
        regions[k].flow_x = 1;
    }
    if (dy < 0) {
        regions[k].flow_y = -1;
    }
    else {
        regions[k].flow_y = 1;
    }
    if(dx) {
        regions[k].speed_x = speed * portion_x;
    }
    else {
        regions[k].speed_x = 0;
    }
    regions[k].speed_y = speed * portion_y;
}